export default class User {
  constructor(nome, cognome, saldo, username, email, password) {
    this.nome = nome,
      this.cognome = cognome,
      this.saldo = saldo,
      this.username = username;
    this.email = email;
    this.password = password;
  }
}
