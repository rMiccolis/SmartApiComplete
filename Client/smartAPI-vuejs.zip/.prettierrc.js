module.exports = {
  singleQuote: true
};
